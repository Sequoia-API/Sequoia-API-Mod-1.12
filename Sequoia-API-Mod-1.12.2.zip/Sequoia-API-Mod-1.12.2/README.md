## 1.12.2 Sequoia Api mod by Timon

This mod is only used for collecting war count data of guild members for our backend system.
Any other data will not be collected.
